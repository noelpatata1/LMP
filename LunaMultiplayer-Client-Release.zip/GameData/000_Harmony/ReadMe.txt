Redistribution of the .Net 4.7.2 Harmony V2 modding library for Kerbal Space Program
Available at : https://github.com/HarmonyKSP/HarmonyKSP
Original distribution : https://github.com/pardeike/Harmony
Licence : MIT