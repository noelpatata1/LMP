Please, BEFORE asking any question check the wiki:
https://github.com/LunaMultiplayer/LunaMultiplayer/wiki

Installation:

---------------------

Client side:
- Copy the contents of the zip file to KSP folder. So in KSP/GameData folder you have both "LunaMultiPlayer" and "000_Harmony" folders

DO NOT put LMPServer in your GameData folder!!!

Server side:
- Copy the folder "LMPServer" to any folder of your choice EXCEPT the KSP folder. Put it preferably on C:/ or in your Desktop

--------------------

Remember: We cannot provide support for other mods in a multiplayer environment so if you have other mods besides LMP expect issues!
